#pragma once
#include<iostream>
#include<string>
using namespace std;
template<class T>
struct Node
{
public:
	T data;
	Node<T>* rightChild;
	Node<T>* leftChild;
	string color;
};