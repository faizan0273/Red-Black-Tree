#pragma once
#include<iostream>
#include<string>
#include"Node.h"
using namespace std;
template<class T>
class RedBlackTree
{
private:
	Node<T>* root;
	void InOrderRec(Node<T>* current)
	{
		if (current == nullptr)
		{
			return;
		}
		InOrderRec(current->leftChild);
		cout << current->data << " " << current->color << endl;
		InOrderRec(current->rightChild);
	}
	void PostOrderRec(Node<T>* current)
	{
		if (current)
		{
			PostOrderRec(current->leftChild);
			PostOrderRec(current->rightChild);
			cout << current->data << " " << current->color << endl;
		}
	}
	void PreOrderRec(Node<T>* current)
	{
		if (current)
		{
			cout << current->data << " " << current->color << endl;
			PreOrderRec(current->leftChild);
			PreOrderRec(current->rightChild);
		}
	}
	void InsertHelper(Node<T>* temp, int value)
	{
		if (value >= temp->data)
		{
			if (temp->rightChild == nullptr)
			{
				Node<T>* NewNode = new Node<T>;
				NewNode->leftChild = nullptr;
				NewNode->rightChild = nullptr;
				//	NewNode->leftChild->color = "black";
					//NewNode->rightChild->color = "black";
				NewNode->data = value;
				NewNode->color = "red";
				temp->rightChild = NewNode;
			}
			else
			{
				InsertHelper(temp->rightChild, value);
			}
		}
		else if (value < temp->data)
		{
			if (temp->leftChild == nullptr)
			{
				Node<T>* NewNode = new Node<T>;
				NewNode->leftChild = nullptr;
				NewNode->rightChild = nullptr;
				//NewNode->leftChild->color = "black";
				//NewNode->rightChild->color = "black";
				NewNode->data = value;
				NewNode->color = "red";
				temp->leftChild = NewNode;
			}
			else
			{
				InsertHelper(temp->leftChild, value);
			}
		}
	}
	void changeUncleColor(Node<T>* root1, T value)
	{
		Node<T>* p = root1;
		Node<T>* u = root1;
		int count = 0;
		if (value > p->data)
		{
			do
			{
				if (p->rightChild->data == value)
				{
					u->leftChild->color = "black";
					return;
				}
				else
				{
					if (count == 0)
					{
						p = p->rightChild;
						count++;
					}
					else
					{
						p = p->rightChild;
						u = u->rightChild;
					}
				}
			} while (p->rightChild != nullptr);
		}
		else
		{
			do
			{
				if (p->leftChild->data == value)
				{
					u->rightChild->color = "black";
					return;
				}
				else
				{
					if (count == 0)
					{
						p = p->leftChild;
						count++;
					}
					else
					{
						p = p->leftChild;
						u = u->leftChild;
					}
				}
			} while (p->leftChild != nullptr);
		}
	}
	void changeParentColor(Node<T>* root1, T value)
	{
		Node<T>* p = root1;
		Node<T>* u = root1;
		int count = 0;
		if (value > p->data)
		{
			do
			{
				if (p->rightChild->data == value)
				{
					if (u->data != root->data)
					{
						p->color = "black;";
						u->color = "red";
					}
					else
					{
						p->color = "black;";
					}
					break;
				}
				else
				{
					if (count == 0)
					{
						p = p->rightChild;
						count++;
					}
					else
					{
						p = p->rightChild;
						u = u->rightChild;
					}
				}
			} while (p->rightChild != nullptr);

		}
		else
		{
			do
			{
				if (p->leftChild->data == value)
				{
					if (u->data != root->data)
					{
						p->color = "black;";
						u->color = "red";
					}
					else
					{
						p->color = "black;";
					}
					break;
				}
				else
				{
					if (count == 0)
					{
						p = p->leftChild;
						count++;
					}
					else
					{
						p = p->leftChild;
						u = u->leftChild;
					}
				}
			} while (p->leftChild != nullptr);
		}
	}
	void deleteAll(Node<T>* current)
	{
		if (current != nullptr)
		{
			deleteAll(current->leftChild);
			deleteAll(current->rightChild);
			delete current;
		}
	}
	void InOrderRec2(Node<T>* current)
	{
		if (current == nullptr)
		{
			return;
		}

		InOrderRec2(current->rightChild);
		cout << current->data << " " << current->color << endl;
		InOrderRec2(current->leftChild);
	}
	void PostOrderRec2(Node<T>* current)
	{
		if (current)
		{
			PostOrderRec2(current->rightChild);
			PostOrderRec2(current->leftChild);
			cout << current->data << " " << current->color << endl;
		}
	}
	void PreOrderRec2(Node<T>* current)
	{
		if (current)
		{
			cout << current->data << " " << current->color << endl;
			PreOrderRec2(current->rightChild);
			PreOrderRec2(current->leftChild);

		}
	}
public:
	RedBlackTree()
	{
		root = nullptr;
	}
	void Insert(T value)
	{
		if (root == nullptr)
		{
			Node<T>* NewNode = new Node<T>;
			NewNode->leftChild = nullptr;
			NewNode->rightChild = nullptr;
			NewNode->data = value;
			NewNode->color = "black";
			root = NewNode;
		}
		else
		{
			InsertHelper(root, value);
			if (checkParentColor(root, value) == "black") {}
			else
			{
				if (checkUncleColor(root, value) == "red")
				{
					changeUncleColor(root, value);
					changeParentColor(root, value);
				}
				else
				{
					if (checkUncleColor(root, value) == "black")
					{

					}
				}
			}
		}
	}
	string checkParentColor(Node<T>* root1, T value)
	{
		Node<T>* p = root1;
		if (value > p->data)
		{
			do
			{
				if (p->rightChild->data == value && p->color == "black")
				{
					return p->color;
				}
				else
				{
					p = p->rightChild;
				}
			} while (p->rightChild != nullptr);
		}
		else
		{
			do
			{
				if (value < p->data)
				{
					if (p->leftChild->data == value && p->color == "black")
					{
						return p->color;
					}
					else
					{
						p = p->leftChild;
					}
				}
			} while (p->leftChild != nullptr);
		}
		return p->color;
	}
	string checkUncleColor(Node<T>* root1, T value)
	{
		Node<T>* p = root1;
		Node<T>* u = root1;
		int count = 0;
		string c = "a";
		if (value > p->data)
		{
			do
			{
				if (p->rightChild->data == value)
				{
					c = u->leftChild->color;
					return c;
				}
				else
				{
					if (count == 0)
					{
						p = p->rightChild;
						count++;
					}
					else
					{
						p = p->rightChild;
						u = u->rightChild;
					}
				}
			} while (p->rightChild != nullptr);

		}
		else
		{
			do
			{
				if (p->leftChild->data == value)
				{
					c = u->rightChild->color;
					return c;
				}
				else
				{
					if (count == 0)
					{
						p = p->leftChild;
						count++;
					}
					else
					{
						p = p->leftChild;
						u = u->leftChild;
					}
				}
			} while (p->leftChild != nullptr);
		}
		return c;
	}
	void InOrder()
	{
		InOrderRec(root);
	}
	void PostOrder()
	{
		PostOrderRec(root);
	}
	void PreOrder()
	{
		PreOrderRec(root);
	}
	void InOrder2()
	{
		InOrderRec2(root);
	}
	void PostOrder2()
	{
		PostOrderRec2(root);
	}
	void PreOrder2()
	{
		PreOrderRec2(root);
	}
	~RedBlackTree()
	{
		deleteAll(root);
	}
	bool search(T val)
	{
		if (root == nullptr)
		{
			cout << "Tree in Empty" << endl;
			return false;
		}

		else if (root->data == val)
		{
			cout << root->data << " found" << endl;
			return true;
		}


		else
		{
			Node<T>* p = root;
			while (1)
			{

				if (val > p->data)
				{
					if (p->rightChild == nullptr)
					{
						cout << val << " not found" << endl;
						return false;
					}

					if (p->rightChild->data == val)
					{
						cout << p->rightChild->data << " found" << endl;
						return true;
					}


					else
						p = p->rightChild;

				}

				else
				{
					if (p->leftChild == nullptr)
					{
						cout << val << " not found" << endl;
						return false;
					}
					if (p->leftChild->data == val)
					{
						cout << p->leftChild->data << " found" << endl;
						return true;
					}
					else
						p = p->leftChild;
				}
			}
		}
	}
	void printparent(T value)
	{
		Node<T>* p = root;
		if (value > p->data)
		{
			do
			{
				if (p->rightChild->data == value)
				{
					cout << p->data;
					return;
				}
				else
				{
					p = p->rightChild;
				}
			} while (p->rightChild != nullptr);
		}
		else
		{
			do
			{
				if (value < p->data)
				{
					if (p->leftChild->data == value)
					{
						cout << p->data;
						return;
					}
					else
					{
						p = p->leftChild;
					}
				}
			} while (p->leftChild != nullptr);
		}

	}
	template<class T>
	bool deleteNode(T data)
	{
		Node<T>* current = find_Node(data);
		Node<T>* previous = find_Previous_Node(data);

		if (current)
		{
			if (current->leftChild && current->rightChild)
			{
				Node<T>* temp = current->rightChild;

				while (temp->leftChild)
				{
					previous = temp;
					temp = temp->leftChild;
				}

				if (temp->rightChild)
				{
					Node<T>* temp_previous = find_Previous_Node(temp->data);

					if (temp_previous->leftChild == temp)
					{
						temp_previous->leftChild = temp->rightChild;
					}
					else
					{
						temp_previous->rightChild = temp->rightChild;
					}
				}
				swap(current->data, temp->data);
				int a = current->data;
				current->data = temp->data;
				temp->data = a;
				current = temp;
			}
			else if (current->leftChild || current->rightChild)
			{
				if (current == root)
				{
					if (current->leftChild)
					{
						root = current->leftChild;
					}
					else
					{
						root = current->rightChild;
					}
				}
				else if (current->leftChild)
				{
					if (previous->leftChild == current)
					{
						previous->leftChild = current->leftChild;
					}
					else
					{
						previous->rightChild = current->leftChild;
					}
				}
				else
				{
					if (previous->leftChild == current)
					{
						previous->leftChild = current->rightChild;
					}
					else
					{
						previous->rightChild = current->rightChild;
					}
				}
			}
			else
			{
				if (current == root)
				{
					root = nullptr;
				}
				else if (previous->leftChild == current)
				{
					previous->leftChild = nullptr;
				}
				else
				{
					previous->rightChild = nullptr;
				}
			}
			delete current;

			return true;
		}
		else
		{
			return false;
		}

	}
	template<class T>
	Node<T>* find_Previous_Node(T d)
	{
		if (root)
		{
			Node<T>* current = root;
			Node<T>* previous = root;

			while (current)
			{
				if (current->data == d)
				{
					if (current == root)
					{
						return nullptr;
					}
					return previous;
				}
				else
				{
					if (d < current->data)
					{
						if (current->leftChild)
						{
							previous = current;
							current = current->leftChild;
						}
					}
					else
					{
						if (current->rightChild)
						{
							previous = current;
							current = current->rightChild;
						}
					}
				}
			}

			return nullptr;
		}
	}
	template<class T>
	Node<T>* find_Node(T d)
	{
		if (root)
		{
			Node<T>* current = root;

			while (current)
			{
				if (current->data == d)
				{
					return current;
				}
				else
				{
					if (d < current->data)
					{
						if (current->leftChild)
						{
							current = current->leftChild;
						}
					}
					else
					{
						if (current->rightChild)
						{
							current = current->rightChild;
						}
					}
				}
			}
			return nullptr;
		}
	}
	void grandparenttouncle(T value)
	{
		Node<T>* p = root;
		Node<T>* u = root;
		int count = 0;
		if (value > p->data)
		{
			do
			{
				if (p->rightChild->data == value)
				{
					u = u->leftChild;

				}
				else
				{
					if (count == 0)
					{
						p = p->rightChild;
						count++;
					}
					else
					{
						p = p->rightChild;
						u = u->rightChild;
					}
				}
			} while (p->rightChild != nullptr);

		}
		else
		{
			do
			{
				if (p->leftChild->data == value)
				{
					u = u->rightChild;
				}
				else
				{
					if (count == 0)
					{
						p = p->leftChild;
						count++;
					}
					else
					{
						p = p->leftChild;
						u = u->leftChild;
					}
				}
			} while (p->leftChild != nullptr);
		}
	}
	void rotateright(T value, Node<T> current)
	{
		grandparenttouncle(value);
	}
};
