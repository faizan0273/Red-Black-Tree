#include<iostream>
#include<string>
#include<fstream>
#include"RedBlackTree.h"
using namespace std;
void menu();
template<class T>
void input(ifstream& fin, RedBlackTree<T> obj);
int main()
{
	int a; int n;
	RedBlackTree<int> obj;
	obj.Insert(10);
	obj.Insert(12);
	obj.Insert(9);
	obj.Insert(8);
	cout << "Inorder:";
	obj.InOrder();
	cout << "Inorder2:";
	obj.InOrder2();
menu1:
	menu();
	cout << "Enter your choice:";
	cin >> a;
	if (a == 1) {
		do
		{
			cout << "Enter a Number you want to insert:";
			cin >> n;
			obj.Insert(n);
			cout << "Enter 1 to continue and 0 for menu";
			cin >> a;
			if (a == 0)
			{
				goto menu1;
			}
		} while (a==1);
	}
	else if (a == 2) {
		cout << "Enter a Value you want to delete:";
		cin >> n;
		obj.deleteNode(n);
		goto menu1;
	}
	else if (a == 3) {
		cout << "Enter a Value you want to search:";
		cin >> n;
		obj.search(n);
		goto menu1;
	}
	else if (a == 4) {
		obj.PreOrder();
		goto menu1;
	}
	else if (a == 5) { obj.InOrder(); goto menu1;
	}
	else if (a == 6) { obj.PostOrder(); goto menu1;
	}
	else if (a == 7) { obj.PreOrder2(); goto menu1;
	}
	else if (a == 8) { obj.InOrder(); goto menu1;
	}
	else if (a == 9) { obj.PostOrder(); goto menu1;
	}
	else if (a == 10) {
		obj.~RedBlackTree();
	}
	else if (a == 11) {

	}
	else if (a == 12) {
		cout << "Enter a Number to printparent:";
		cin >> n;
		obj.printparent(n);
		goto menu1;
	}
	else if (a == 13) {
		ifstream fin("input.txt");
		input(fin, obj);
		goto menu1;
	}
	else if (a == 14) {
		return 0;
	}

}


template<class T>
void input(ifstream& fin, RedBlackTree<T> obj)
{
	int ch = 0;
	while (fin >> ch)
	{
		obj.Insert(ch);
	}
}
void menu()
{
	cout << "\n\n";
	cout << "Press 1 to insert values one by one in the tree\n";
	cout << "Press 2 to delete a value from the tree(bonus / optional)\n";
	cout << "Press 3 for searching a value from the tree\n";
	cout << "Press 4 for pre - order traversal NLR \n";
	cout << "Press 5 for in - order traversal LNR \n";
	cout << "Press 6 for post - order traversal LRN \n";
	cout << "Press 7 for pre - order traversal 2 NRL \n";
	cout << "Press 8 for in - order traversal 2 RNL \n";
	cout << "Press 9 for post - order traversal 2 RLN \n";
	cout << "Press 10 to destroy the tree(all nodes must be deleted) \n";
	cout << "Press 11 to delete all values in the tree greater than X \n";
	cout << "Press 12 for displaying parent of a node present in Tree \n";
	cout << "Press 13 to read integer values from the file �input.txt to create a red - black tree \n";
	cout << "Press 14 to EXIT \n";
}